# @vn-gis/map

Thư viện JavaScript/TypeScript hiển thị bản đồ GIS Việt Nam: tỉnh/thành, xã/phường và custom GeoJSON layers. Hỗ trợ cả **Leaflet** và **MapLibre GL JS** thông qua kiến trúc renderer-agnostic, tích hợp sẵn với [vn-gis-api](https://github.com/vn-gis).

## Tính năng

- Hiển thị toàn bộ tỉnh/thành Việt Nam chỉ với một dòng lệnh
- Hiển thị xã/phường theo từng tỉnh
- Thêm custom GeoJSON layer từ URL hoặc data inline
- Reverse geocoding (toạ độ → xã/phường/tỉnh)
- Chọn renderer: Leaflet hoặc MapLibre GL JS
- Style tĩnh, style động (theo feature), popup và tooltip
- Cache HTTP theo TTL, Bearer auth
- Typed events, TypeScript declarations đầy đủ
- Bundle ESM / CJS / UMD

## Cài đặt

```bash
npm install @vn-gis/map
```

Cài renderer bạn muốn dùng (peer dependency — chỉ cần một trong hai):

```bash
# Dùng Leaflet
npm install leaflet

# hoặc dùng MapLibre
npm install maplibre-gl
```

## Bắt đầu nhanh

### Với Leaflet

```ts
import { VNGisMap } from '@vn-gis/map';
import { LeafletRenderer } from '@vn-gis/map/leaflet';
import * as L from 'leaflet';
import 'leaflet/dist/leaflet.css';

const map = new VNGisMap(
  {
    container: 'map',
    renderer: 'leaflet',
    apiBaseUrl: 'https://api.example.com',
    token: 'YOUR_API_TOKEN',
    layers: { provinces: true },
    onProvinceClick: (feature) => {
      console.log('Tỉnh:', feature.properties?.name);
    },
  },
  () => new LeafletRenderer(L),
);
```

### Với MapLibre

```ts
import { VNGisMap } from '@vn-gis/map';
import { MapLibreRenderer } from '@vn-gis/map/maplibre';
import maplibregl from 'maplibre-gl';
import 'maplibre-gl/dist/maplibre-gl.css';

const map = new VNGisMap(
  {
    container: 'map',
    renderer: 'maplibre',
    apiBaseUrl: 'https://api.example.com',
    token: 'YOUR_API_TOKEN',
    layers: { provinces: true },
  },
  () => new MapLibreRenderer(maplibregl),
);
```

## Cấu hình `VNMapConfig`

| Thuộc tính | Kiểu | Mô tả |
| --- | --- | --- |
| `container` | `string \| HTMLElement` | ID/selector hoặc element chứa map |
| `renderer` | `'leaflet' \| 'maplibre'` | Loại renderer |
| `apiBaseUrl` | `string` | Base URL của vn-gis-api |
| `token` | `string` | Bearer token |
| `initialView` | `{ center: [lng, lat]; zoom: number }` | View ban đầu (mặc định: toàn VN) |
| `initialBounds` | `Bounds` | Fit bounds khi khởi tạo |
| `layers` | `InitialLayers` | Layers nạp sẵn khi ready |
| `tileUrl` | `string` | Template URL base tiles (mặc định OSM) |
| `attribution` | `string` | Attribution |
| `onProvinceClick` | `(feature) => void` | Callback click tỉnh |
| `onWardClick` | `(feature) => void` | Callback click xã/phường |
| `onCustomLayerClick` | `(feature, layerId) => void` | Callback click custom layer |
| `cacheTtl` | `number` | TTL cache API (giây, mặc định 600) |

## API chính

### Layers

```ts
// Hiển thị tất cả tỉnh/thành
await map.showProvinces({ style: { fillColor: '#4a90d9' } });
map.hideProvinces();

// Hiển thị xã/phường của một tỉnh (theo mã tỉnh)
await map.showWards('01');
map.hideWards('01');

// Custom GeoJSON layer từ URL hoặc inline
const id = await map.addCustomLayer('https://cdn.example.com/rivers.geojson');
const id2 = await map.addCustomLayer(geojsonObject, { style: { strokeColor: '#f00' } });

// Quản lý layer
map.setLayerStyle(id, { fillColor: '#00ff00' });
map.setLayerVisibility(id, false);
map.toggleLayer(id);
map.removeLayer(id);
```

### Style động

```ts
await map.showProvinces({
  styleFunction: (feature) => {
    const area = Number(feature.properties?.area_km2 ?? 0);
    return { fillColor: area > 5000 ? '#c0392b' : '#4a90d9' };
  },
});
```

### Reverse geocoding

```ts
const result = await map.reverseGeocode(105.85, 21.02);
if (result.found) {
  console.log(result.ward?.province_name, result.ward?.ward_name);
}
```

### Navigation

```ts
map.setView([105.85, 21.02], 11); // [lng, lat], zoom
map.fitBounds([
  [8.18, 102.14], // [south, west]
  [23.39, 109.47], // [north, east]
]);
```

### Events

```ts
map.on('ready', () => console.log('Map sẵn sàng'));
map.on('click', (e) => console.log(e.lngLat, e.feature));
map.once('moveend', (e) => console.log('Di chuyển xong'));
map.off('click', handler);
```

Các event hỗ trợ: `ready`, `click`, `mousemove`, `zoomstart`, `zoomend`, `movestart`, `moveend`, `load`, `error`.

### Popup & tooltip

```ts
await map.showProvinces({
  popup: {
    contentTemplate: (f) => `<b>${f.properties?.name}</b>`,
  },
  tooltip: true, // dùng tên feature làm tooltip
});
```

## Truy cập cấp thấp

```ts
map.getRenderer();      // IRenderer đang dùng
map.getApiClient();     // ApiClient
map.getLayerManager();  // LayerManager

// Map native (Leaflet.Map hoặc maplibregl.Map)
const native = (map.getRenderer() as LeafletRenderer).getNativeMap();
```

## Dọn dẹp

```ts
map.destroy(); // giải phóng map, layers, listeners, cache
```

## Constants & helpers

```ts
import {
  VN_BOUNDS,
  VN_CENTER_LNGLAT,
  VN_DEFAULT_ZOOM,
  VN_MAP_ZOOM,
  VN_STYLE_PRESETS,
  mergeStyle,
  isFeature,
  isFeatureCollection,
} from '@vn-gis/map';
```

## Development

```bash
npm install
npm run typecheck   # kiểm tra kiểu
npm run lint        # lint
npm test            # chạy unit tests
npm run build       # build ESM/CJS/UMD + d.ts
```

Xem thư mục `examples/` cho ví dụ HTML chạy trực tiếp trên trình duyệt.

## License

[MIT](./LICENSE)
